package cloud.azure.team;

import cloud.azure.team.config.kafka.KafkaProcessor;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.stream.annotation.StreamListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

@Service
public class PolicyHandler{

    @Autowired
    DashboardRepository repository;

    @StreamListener(KafkaProcessor.INPUT)
    public void when_CREATE_orderPlaced(@Payload OrderPlaced orderPlaced){
        if(orderPlaced.isMe()){
            Dashboard dashboard = new Dashboard();
            dashboard.setOrderId(orderPlaced.getId());
            dashboard.setProductId(orderPlaced.getProductId());
           
            dashboard.setOrderStatus(OrderPlaced.class.getSimpleName());
            repository.save(dashboard);
        }
    }

    @StreamListener(KafkaProcessor.INPUT)
    public void when_UPDATE_DeliveryStarted(@Payload DeliveryStarted deliveryStarted){
        if(deliveryStarted.isMe()){
            Dashboard dashboard = repository.findById(deliveryStarted.getOrderId()).orElse(null);;
            if( dashboard != null ){
                dashboard.setOrderId (deliveryStarted.getId());
                dashboard.setOrderStatus(DeliveryStarted.class.getSimpleName());
                repository.save(dashboard);
            }
        }
    }

    @StreamListener(KafkaProcessor.INPUT)
    public void when_UPDATE_DeliveryCancelled(@Payload DeliveryCanceled deliveryCancelled){
        if(deliveryCancelled.isMe()){
            Dashboard dashboard = repository.findById(deliveryCancelled.getOrderId()).orElse(null);;
            if( dashboard != null ){
                dashboard.setOrderId(deliveryCancelled.getId());
                dashboard.setOrderStatus(DeliveryCanceled.class.getSimpleName());
                repository.save(dashboard);
            }
        }
    }

    @StreamListener(KafkaProcessor.INPUT)
    public void when_UPDATE_ReturnRequested(@Payload ReturnRequested returnRequested){

        if(!returnRequested.validate()) return;

        Dashboard dashboard =  repository.findById(returnRequested.getOrderId()).orElse(null);;
        dashboard.setOrderId(returnRequested.getId());
        dashboard.setOrderStatus("Service Ended. Product will be picked up.");

    }

    @StreamListener(KafkaProcessor.INPUT)
    public void whatever(@Payload String eventString){
        System.out.println("\n\n##### Dashboard : " + eventString + "\n\n");
    }


}