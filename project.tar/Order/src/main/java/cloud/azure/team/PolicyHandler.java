package cloud.azure.team;

import cloud.azure.team.config.kafka.KafkaProcessor;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.stream.annotation.StreamListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

@Service
public class PolicyHandler{
    @Autowired OrderRepository orderRepository;

    // @Value("${com.property.value}")
    // String configMapValue;

    @StreamListener(KafkaProcessor.INPUT)
    public void wheneverDeliveryStarted_ChangeOrderStatus(@Payload DeliveryStarted deliveryStarted){

        if(!deliveryStarted.validate()) return;

        System.out.println("\n\n##### listener ChangeOrderStatus : " + deliveryStarted.toJson() + "\n\n");
        //System.out.println("\n\n##### Customer Message : " + configMapValue.toString() + "\n\n");

        java.util.Optional<Order> optionalOrder = orderRepository.findById(deliveryStarted.getOrderId());
        Order order = optionalOrder.get();
        order.setOrderId(deliveryStarted.getId());
        order.setOrderStatus(deliveryStarted.getDeliveryStatus());
        orderRepository.save(order);

    }
    @StreamListener(KafkaProcessor.INPUT)
    public void wheneverDeliveryCanceled_ChangeOrderStatus(@Payload DeliveryCanceled deliveryCanceled){

        if(!deliveryCanceled.validate()) return;

        System.out.println("\n\n##### listener ChangeOrderStatus : " + deliveryCanceled.toJson() + "\n\n");

        java.util.Optional<Order> optionalOrder = orderRepository.findById(deliveryCanceled.getOrderId());
        Order order = optionalOrder.get();
        order.setOrderId(deliveryCanceled.getId());
        order.setOrderStatus(deliveryCanceled.getDeliveryStatus());
        orderRepository.save(order);
    }


    @StreamListener(KafkaProcessor.INPUT)
    public void whatever(@Payload String eventString){}


}