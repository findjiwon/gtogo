package cloud.azure.team.external;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class DeliveryServiceImpl implements DeliveryService{

    /**
     * 배송 fallback
     */

    @Override
    public void startShipping(Delivery delivery) {
        // TODO Auto-generated method stub
        System.out.println("@@@@@@@ 배송이 지연중 입니다. @@@@@@@@@@@@");
        System.out.println("@@@@@@@ 배송이 지연중 입니다. @@@@@@@@@@@@");
        System.out.println("@@@@@@@ 배송이 지연중 입니다. @@@@@@@@@@@@");
    }

}
