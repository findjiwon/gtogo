package cloud.azure.team;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class MarketingServiceImpl implements MarketingService {
    @Autowired
    MarketingRepository marketingRepository;

    public Marketing getRunninMarketing(Long id){

        Optional<Marketing> productOptional = marketingRepository.findById(id);
        Marketing product = productOptional.get();

        // try {
        //     Thread.currentThread();
        //     Thread.sleep((long) (4000 + Math.random() * 220));
        // } catch (final InterruptedException e) {
        //     e.printStackTrace();
        // }
        
        return product;
    }
}