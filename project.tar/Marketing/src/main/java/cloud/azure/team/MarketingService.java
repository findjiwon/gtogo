package cloud.azure.team;

public interface MarketingService {
    Marketing getRunninMarketing(Long id);
}