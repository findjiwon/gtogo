package cloud.azure.team;

import javax.persistence.*;
import org.springframework.beans.BeanUtils;

import cloud.azure.team.external.OrderService;

import java.util.List;
import java.util.Date;

@Entity
@Table(name="Marketing_table")
public class Marketing {

    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    private Long id;
    private Long productId;
    private String productName;
    private Long planQty;
    private Date startDate;
    private Date endDate;
    private String planTitle;

    @PostPersist
    public void onPostPersist(){
        ServiceStrted serviceStrted = new ServiceStrted();
        BeanUtils.copyProperties(this, serviceStrted);
        serviceStrted.publishAfterCommit();
    }

    @PostUpdate
    public void onPostUpdate(){

        // OrderService orderSvc = MarketingApplication.applicationContext.getBean(OrderService.class);
        // orderSvc.returnToGo(this.getId());

        //cloud.azure.team.external.Order order = new cloud.azure.team.external.Order();
        MarketingApplication.applicationContext.getBean(cloud.azure.team.external.OrderService.class).returnToGo(this.getId());

        ServiceEnded serviceEnded = new ServiceEnded();
        BeanUtils.copyProperties(this, serviceEnded);
        serviceEnded.publishAfterCommit();

    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
    public Long getProductId() {
        return productId;
    }

    public void setProductId(Long productId) {
        this.productId = productId;
    }
    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }
    public Long getPlanQty() {
        return planQty;
    }

    public void setPlanQty(Long planQty) {
        this.planQty = planQty;
    }
    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }
    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }
    public String getPlanTitle() {
        return planTitle;
    }

    public void setPlanTitle(String planTitle) {
        this.planTitle = planTitle;
    }




}